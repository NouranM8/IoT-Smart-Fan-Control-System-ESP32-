#include <WiFi.h>
#include <WebServer.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include "DHT.h"

// ================= WIFI =================
const char* ssid = "iPhone";
const char* password = "Nouran77";

WebServer server(80);

// ================= OLED =================
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64

Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// ================= PINS =================
#define DHTPIN 13
#define DHTTYPE DHT22

#define RELAY_PIN 33
#define PIR_PIN 27
#define BUZZER_PIN 15

// ================= RELAY =================
#define RELAY_ON HIGH
#define RELAY_OFF LOW

// ================= SENSOR =================
DHT dht(DHTPIN, DHTTYPE);

// ================= VARIABLES =================
float temperature = 0;
float humidity = 0;

bool motionDetected = false;
bool fanState = false;
bool manualMode = false;

unsigned long lastMotionTime = 0;
unsigned long lastSensorRead = 0;
unsigned long lastSerialPrint = 0;

// ================= SETTINGS =================
const float TEMP_ON = 22.0;
const float TEMP_OFF = 24.0;

const unsigned long MOTION_TIMEOUT = 10000;

// ================= HTML PAGE =================
String webpage() {

  String page = "<!DOCTYPE html><html><head>";

  page += "<meta name='viewport' content='width=device-width, initial-scale=1'>";

  page += "<style>";
  page += "body{background:#111;color:white;font-family:Arial;text-align:center;}";
  page += ".card{background:#1e1e1e;margin:20px;padding:20px;border-radius:20px;}";
  page += "button{padding:15px 25px;margin:5px;border:none;border-radius:10px;font-size:16px;}";
  page += ".on{background:green;color:white;}";
  page += ".off{background:red;color:white;}";
  page += ".auto{background:blue;color:white;}";
  page += "</style>";

  page += "</head><body>";

  page += "<h2>SMART FAN SYSTEM</h2>";

  page += "<div class='card'>";

  page += "<h3>Temperature: " + String(temperature) + " C</h3>";
  page += "<h3>Humidity: " + String(humidity) + " %</h3>";

  page += "<h3>Motion: ";
  page += motionDetected ? "YES" : "NO";
  page += "</h3>";

  page += "<h3>Fan: ";
  page += fanState ? "ON" : "OFF";
  page += "</h3>";

  page += "<h3>Mode: ";
  page += manualMode ? "MANUAL" : "AUTO";
  page += "</h3>";

  page += "<a href='/on'><button class='on'>ON</button></a>";
  page += "<a href='/off'><button class='off'>OFF</button></a>";
  page += "<a href='/auto'><button class='auto'>AUTO</button></a>";

  page += "</div>";

  page += "</body></html>";

  return page;
}

// ================= SETUP =================
void setup() {

  Serial.begin(115200);

  // ===== START DHT =====
  dht.begin();

  // ===== PINS =====
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(PIR_PIN, INPUT);
  pinMode(BUZZER_PIN, OUTPUT);

  digitalWrite(RELAY_PIN, RELAY_OFF);

  // ===== OLED =====
  if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {

    Serial.println("OLED FAILED");

    while (true);
  }

  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);

  // ================= WIFI =================
  WiFi.mode(WIFI_STA);

  WiFi.setSleep(false);

  display.clearDisplay();
  display.setCursor(0,0);
  display.println("Connecting WiFi...");
  display.display();

  Serial.println("Connecting WiFi...");

  WiFi.begin(ssid, password);

  int timeout = 30;

  while (WiFi.status() != WL_CONNECTED && timeout > 0) {

    delay(500);

    Serial.print(".");

    timeout--;
  }

  // ===== WIFI SUCCESS =====
  if (WiFi.status() == WL_CONNECTED) {

    Serial.println("");
    Serial.println("WiFi Connected!");

    Serial.print("IP Address: ");
    Serial.println(WiFi.localIP());

    display.clearDisplay();

    display.setCursor(0,0);
    display.println("WiFi Connected!");

    display.println("");

    display.println(WiFi.localIP());

    display.display();
  }

  // ===== WIFI FAILED =====
  else {

    Serial.println("");
    Serial.println("WiFi FAILED!");

    display.clearDisplay();

    display.setCursor(0,0);
    display.println("WiFi FAILED!");
    display.println("Check Hotspot");

    display.display();
  }

  // ================= SERVER ROUTES =================

  // ===== HOME PAGE =====
  server.on("/", []() {

    server.send(200, "text/html", webpage());
  });

  // ===== FAN ON =====
  server.on("/on", []() {

    manualMode = true;

    fanState = true;

    digitalWrite(RELAY_PIN, RELAY_ON);

    server.send(200, "text/html", webpage());
  });

  // ===== FAN OFF =====
  server.on("/off", []() {

    manualMode = true;

    fanState = false;

    digitalWrite(RELAY_PIN, RELAY_OFF);

    server.send(200, "text/html", webpage());
  });

  // ===== AUTO MODE =====
  server.on("/auto", []() {

    manualMode = false;

    server.send(200, "text/html", webpage());
  });

  // ===== JSON DATA =====
  server.on("/data", []() {

    String json = "{";

    json += "\"temp\":" + String(temperature) + ",";
    json += "\"hum\":" + String(humidity) + ",";
    json += "\"motion\":" + String(motionDetected) + ",";
    json += "\"fan\":" + String(fanState);

    json += "}";

    server.send(200, "application/json", json);
  });

  // ===== START SERVER =====
  server.begin();

  Serial.println("Server Started!");
}

// ================= LOOP =================
void loop() {

  // ===== HANDLE WEB CLIENT =====
  server.handleClient();

  unsigned long now = millis();

  // ================= PIR CHECK =================
  if (digitalRead(PIR_PIN) == HIGH) {

    motionDetected = true;

    lastMotionTime = now;
  }

  // ================= MOTION TIMEOUT =================
  if (now - lastMotionTime > MOTION_TIMEOUT) {

    motionDetected = false;
  }

  // ================= SENSOR READ =================
  if (now - lastSensorRead > 500) {

    lastSensorRead = now;

    float t = dht.readTemperature();

    float h = dht.readHumidity();

    if (!isnan(t) && !isnan(h)) {

      temperature = t;

      humidity = h;
    }
  }

  // ================= AUTO CONTROL =================
if (!manualMode) {

  // ===== TURN ON =====
  if (temperature > TEMP_ON && motionDetected) {

    fanState = true;

    digitalWrite(RELAY_PIN, RELAY_ON);
  }

  // ===== TURN OFF =====
  else if (!motionDetected || temperature < TEMP_OFF) {

    fanState = false;

    digitalWrite(RELAY_PIN, RELAY_OFF);
  }
}

  // ================= BUZZER =================

  // VERY HOT
  if (temperature > 40) {

    tone(BUZZER_PIN, 2000);
  }

  // HOT
  else if (temperature > 35) {

    tone(BUZZER_PIN, 1000);
  }

  // NORMAL
  else {

    noTone(BUZZER_PIN);
  }

  // ================= OLED DISPLAY =================
  display.clearDisplay();

  display.setCursor(0,0);
  display.println("SMART FAN");

  display.setCursor(0,15);
  display.print("Temp: ");
  display.print(temperature);
  display.println(" C");

  display.setCursor(0,28);
  display.print("Hum : ");
  display.print(humidity);
  display.println(" %");

  display.setCursor(0,41);
  display.print("Motion: ");
  display.print(motionDetected ? "YES" : "NO");

  display.setCursor(0,54);
  display.print("Fan: ");
  display.print(fanState ? "ON" : "OFF");

  display.display();

  // ================= SERIAL MONITOR =================
  if (now - lastSerialPrint > 1000) {

    lastSerialPrint = now;

    Serial.println("========== STATUS ==========");

    Serial.print("Temperature: ");
    Serial.println(temperature);

    Serial.print("Humidity: ");
    Serial.println(humidity);

    Serial.print("Motion: ");
    Serial.println(motionDetected);

    Serial.print("Fan: ");
    Serial.println(fanState);

    Serial.print("IP: ");
    Serial.println(WiFi.localIP());

    Serial.println("============================");
  }
}